package com.proman280.randomblockdrops.mixin;

import com.proman280.randomblockdrops.RandomBlockDrops;
import net.minecraft.class_2338;
import net.minecraft.class_3225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3225.class)
public class PlayerInteractionMixin {

	@Inject(
			method = "destroyBlock",
			at = @At("HEAD")
	)
	private void randomblockdrops$trackBlockBreak(
			class_2338 pos,
			CallbackInfoReturnable<Boolean> cir
	) {
		class_3225 gameMode = (class_3225)(Object)this;

		RandomBlockDrops.setLastBreak(
				pos,
				gameMode.method_14268()
		);
	}
}