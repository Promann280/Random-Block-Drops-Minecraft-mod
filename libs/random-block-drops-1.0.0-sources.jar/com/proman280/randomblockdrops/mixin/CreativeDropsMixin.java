package com.proman280.randomblockdrops.mixin;

import com.proman280.randomblockdrops.DropOperationContext;
import com.proman280.randomblockdrops.RandomBlockDrops;
import com.proman280.randomblockdrops.RandomDropState;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Creative destruction bypasses Block.playerDestroy, so handle the successful operation here. */
@Mixin(class_3225.class)
public abstract class CreativeDropsMixin {
	// ===== Shadowed Fields =====
	@Shadow protected net.minecraft.class_3218 level;
	@Shadow protected net.minecraft.class_3222 player;
	@Shadow public abstract boolean isCreative();

	// ===== Unique State =====
	@Unique private class_2680 randomblockdrops$pending;

	// ===== Injection Points =====
	@Inject(method = "destroyBlock", at = @At("HEAD"))
	private void randomblockdrops$capture(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
		randomblockdrops$pending = isCreative() ? level.method_8320(pos) : null;
	}
	@Inject(method = "destroyBlock", at = @At("RETURN"))
	private void randomblockdrops$cleanup(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
		// ===== In creative mode, prevent any drops from occurring =====
		if (isCreative() && cir.getReturnValue() && randomblockdrops$pending != null) {
			DropOperationContext.begin();
			DropOperationContext.markEmitted();
			DropOperationContext.end();
		}
		// ===== Cleanup =====
		randomblockdrops$pending = null;
	}
}
