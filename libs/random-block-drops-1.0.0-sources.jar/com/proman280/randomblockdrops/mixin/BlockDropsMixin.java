package com.proman280.randomblockdrops.mixin;

import com.proman280.randomblockdrops.RandomBlockDrops;
import com.proman280.randomblockdrops.RandomDropState;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1937;
import net.minecraft.class_2244;
import net.minecraft.class_2248;
import net.minecraft.class_2320;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2742;
import net.minecraft.class_2756;
import net.minecraft.class_7924;
import com.proman280.randomblockdrops.DropOperationContext;
import com.proman280.randomblockdrops.ExplosionDropContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


@Mixin(class_2248.class)
public abstract class BlockDropsMixin {

	@Inject(
			method = "dropResources(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/entity/BlockEntity;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/item/ItemStack;)V",
			at = @At("HEAD"),
			cancellable = true
	)
	private static void randomblockdrops$replaceLoot(
			class_2680 state,
			class_1937 level,
			class_2338 pos,
			class_2586 blockEntity,
			class_1297 entity,
			class_1799 tool,
			CallbackInfo ci
	) {

		if (level.method_8608() || level.method_8503() == null) {
			return;
		}

		if (ExplosionDropContext.active()) {
			return;
		}

		if (entity instanceof class_1657 player && player.method_7337()) {
			ci.cancel();
			return;
		}

		if (RandomDropState.wasCreativeBreak(pos)) {
			RandomDropState.clearBreak();
			ci.cancel();
			return;
		}

		if (state.method_26204() instanceof net.minecraft.class_2397
				&& !(entity instanceof class_1657)) {
			return;
		}

		if (state.method_26204() instanceof class_2323
				&& state.method_11654(class_2323.field_10946) == class_2756.field_12609) {
			ci.cancel();
			return;
		}

		if (state.method_26204() instanceof class_2320
				&& state.method_11654(class_2320.field_10929) == class_2756.field_12609) {
			ci.cancel();
			return;
		}

		if (state.method_26204() instanceof class_2244
				&& state.method_11654(class_2244.field_9967) == class_2742.field_12557) {
			ci.cancel();
			return;
		}

		if (DropOperationContext.active() && DropOperationContext.emitted()) {
			ci.cancel();
			return;
		}

		if (tool != null &&
				class_1890.method_8225(
						level.method_30349()
								.method_46762(class_7924.field_41265)
								.method_46747(class_1893.field_9099),
						tool) > 0) {
			return;
		}

		RandomDropState random = RandomBlockDrops.state(level.method_8503());

		if (!random.shouldRandomize(state.method_26204())) {
			return;
		}

		class_1799 drop = random.dropFor(state.method_26204());

		if (!drop.method_7960()) {
			class_2248.method_9577(level, pos, drop);
		}

		DropOperationContext.markEmitted();
		ci.cancel();
	}
}