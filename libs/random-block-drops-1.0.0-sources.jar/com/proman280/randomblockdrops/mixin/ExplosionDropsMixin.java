package com.proman280.randomblockdrops.mixin;

import com.proman280.randomblockdrops.ExplosionDropContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.BiConsumer;
import net.minecraft.class_1799;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4970;

/** Keeps the shared drop hook from replacing vanilla loot while an explosion destroys a block. */
@Mixin(class_4970.class)
public abstract class ExplosionDropsMixin {
	// ===== Injection Points =====
	@Inject(method = "onExplosionHit(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/Explosion;Ljava/util/function/BiConsumer;)V", at = @At("HEAD"))
	private void randomblockdrops$beginExplosionDrop(class_2680 state, class_1937 level, class_2338 pos, class_1927 explosion, BiConsumer<class_1799, class_2338> dropConsumer, CallbackInfo ci) {
		ExplosionDropContext.begin();
	}

	@Inject(method = "onExplosionHit(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/Explosion;Ljava/util/function/BiConsumer;)V", at = @At("RETURN"))
	private void randomblockdrops$endExplosionDrop(class_2680 state, class_1937 level, class_2338 pos, class_1927 explosion, BiConsumer<class_1799, class_2338> dropConsumer, CallbackInfo ci) {
		ExplosionDropContext.end();
	}
}
