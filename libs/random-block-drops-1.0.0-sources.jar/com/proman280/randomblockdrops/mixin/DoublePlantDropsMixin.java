package com.proman280.randomblockdrops.mixin;

import net.minecraft.class_1937;
import net.minecraft.class_2320;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Prevents double plants from calling popResource multiple times. */
@Mixin(class_2320.class)
public abstract class DoublePlantDropsMixin {
	@Inject(method = "popResource", at = @At("HEAD"), cancellable = true)
	private void randomblockdrops$preventDoubleDrops(class_1937 level, class_2338 pos, class_2680 state, CallbackInfo ci) {
		// Let BlockDropsMixin handle the random drop via dropResources
		ci.cancel();
	}
}
