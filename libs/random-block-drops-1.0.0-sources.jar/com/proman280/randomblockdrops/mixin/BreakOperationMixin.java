package com.proman280.randomblockdrops.mixin;

import com.proman280.randomblockdrops.DropOperationContext;
import net.minecraft.class_2338;
import net.minecraft.class_3225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3225.class)
public abstract class BreakOperationMixin {
	// ===== Injection Points =====
	@Inject(method = "destroyBlock", at = @At("HEAD"))
	private void randomblockdrops$begin(class_2338 pos, CallbackInfoReturnable<Boolean> cir) { DropOperationContext.begin(); }
	@Inject(method = "destroyBlock", at = @At("RETURN"))
	private void randomblockdrops$end(class_2338 pos, CallbackInfoReturnable<Boolean> cir) { DropOperationContext.end(); }
}
