package com.proman280.randomblockdrops.client;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import net.minecraft.class_310;

/** Exposes a UI only when Mod Menu is installed on the local client. */
public final class ModMenuIntegration implements ModMenuApi {
	// ===== ModMenu API Implementation =====
	@Override
	public ConfigScreenFactory<?> getModConfigScreenFactory() {
		return parent -> new RandomBlockDropsScreen(parent);
	}

	// ===== Command Helper =====
	static void command(String command) {
		if (class_310.method_1551().field_1724 != null) class_310.method_1551().field_1724.field_3944.method_45730(command);
	}
}
