package com.proman280.randomblockdrops.client;

import com.proman280.randomblockdrops.RandomBlockDrops;
import com.proman280.randomblockdrops.RandomDropState;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * A deliberately dependency-free Mod Menu screen. Actions use server commands, so the
 * server remains authoritative and the same controls work for clients without this UI.
 */
final class RandomBlockDropsScreen extends class_437 {
	// ===== Instance Fields =====
	private final class_437 parent;
	private boolean enabled = true;

	// ===== Constructor =====
	RandomBlockDropsScreen(class_437 parent) { super(class_2561.method_43470("Random Block Drops")); this.parent = parent; }

	// ===== Screen Initialization =====
	@Override protected void method_25426() {
		loadSingleplayerState();
		int left = field_22789 / 2 - 110;
		method_37063(class_4185.method_46430(class_2561.method_43470("Randomize Loot Pool"), b -> ModMenuIntegration.command("rbd randomize")).method_46434(left, 64, 220, 22).method_46431());
		method_37063(class_4185.method_46430(label("Random Drops", enabled), b -> { enabled = !enabled; toggle(b, "Random Drops", enabled, "rbd toggle"); }).method_46434(left, 94, 220, 22).method_46431());
	}

	// ===== Helper Methods =====
	private void loadSingleplayerState() { if (field_22787.method_1576() != null) { RandomDropState state = RandomBlockDrops.state(field_22787.method_1576()); enabled = state.enabled(); } }
	private class_2561 label(String name, boolean on) { return class_2561.method_43470(name + ": " + (on ? "ON" : "OFF")).method_27692(on ? class_124.field_1060 : class_124.field_1061); }
	private void toggle(class_4185 button, String label, boolean on, String command) { ModMenuIntegration.command(command); button.method_25355(label(label, on)); }
	// ===== Rendering =====
	@Override public void method_25394(net.minecraft.class_332 graphics, int mouseX, int mouseY, float delta) {
		method_25420(graphics, mouseX, mouseY, delta); graphics.method_27534(field_22793, field_22785, field_22789 / 2, 18, 0xFFFFFF);
		graphics.method_27534(field_22793, class_2561.method_43470("Server-authoritative settings • Operators only"), field_22789 / 2, 34, 0xA0A0A0);
		super.method_25394(graphics, mouseX, mouseY, delta);
	}

	// ===== Screen Lifecycle =====
	@Override public void method_25419() { field_22787.method_1507(parent); }
}
