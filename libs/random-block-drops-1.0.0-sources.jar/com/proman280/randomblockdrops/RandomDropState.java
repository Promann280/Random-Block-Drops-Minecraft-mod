package com.proman280.randomblockdrops;

import net.minecraft.class_1799;
import net.minecraft.class_18;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_5819;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

// Thread-local storage for tracking last break context
class BreakContext {
	private static final ThreadLocal<class_2338> lastPos = new ThreadLocal<>();
	private static final ThreadLocal<Boolean> lastWasCreative = new ThreadLocal<>();

	static void set(class_2338 pos, boolean isCreative) {
		lastPos.set(pos);
		lastWasCreative.set(isCreative);
	}

	static class_2338 getLastPos() {
		return lastPos.get();
	}

	static boolean getLastWasCreative() {
		Boolean val = lastWasCreative.get();
		return val != null && val;
	}

	static void clear() {
		lastPos.remove();
		lastWasCreative.remove();
	}
}

/** Saved once per world. IDs, rather than raw registry objects, make the data portable. */
public final class RandomDropState extends class_18 {
	// ===== Constants =====
	private static final String DATA_NAME = "randomblockdrops";
	private static final Set<String> OPERATOR_BLOCKS = Set.of(
		"minecraft:command_block", "minecraft:chain_command_block", "minecraft:repeating_command_block",
		"minecraft:structure_block", "minecraft:structure_void", "minecraft:barrier", "minecraft:jigsaw", "minecraft:light",
		"minecraft:water", "minecraft:flowing_water", "minecraft:lava", "minecraft:flowing_lava");

	// ===== Instance Fields =====
	private final Map<class_2960, class_2960> mappings = new HashMap<>();
	private long seed;
	private boolean enabled = true;

	// ===== Factory Methods =====
	public static RandomDropState get(MinecraftServer server) {
		RandomDropState state = server.method_30002().method_17983().method_17924(
			new class_18.class_8645<>(RandomDropState::new, RandomDropState::load, null), DATA_NAME);
		state.ensureCurrentPool();
		return state;
	}

	// ===== Constructors =====
	private RandomDropState() { regenerate(class_5819.method_43047().method_43055()); }

	// ===== Loading/Saving =====
	private static RandomDropState load(class_2487 tag, class_7225.class_7874 registries) {
		RandomDropState state = new RandomDropState();
		state.seed = tag.method_10537("seed");
		state.enabled = !tag.method_10545("enabled") || tag.method_10577("enabled");
		state.mappings.clear();
		for (class_2520 entry : tag.method_10554("mappings", class_2520.field_33260)) {
			class_2487 pair = (class_2487) entry;
			class_2960 source = class_2960.method_12829(pair.method_10558("source"));
			class_2960 target = class_2960.method_12829(pair.method_10558("target"));
			if (source != null && target != null) state.mappings.put(source, target);
		}
		return state;
	}

	@Override
	public class_2487 method_75(class_2487 tag, class_7225.class_7874 registries) {
		tag.method_10544("seed", seed);
		tag.method_10556("enabled", enabled);
		class_2499 pairs = new class_2499();
		mappings.forEach((source, target) -> { class_2487 pair = new class_2487(); pair.method_10582("source", source.toString()); pair.method_10582("target", target.toString()); pairs.add(pair); });
		tag.method_10566("mappings", pairs);
		return tag;
	}

	// ===== Public Query Methods =====
	public boolean shouldRandomize(class_2248 block) { return enabled && mappings.containsKey(class_7923.field_41175.method_10221(block)); }
	public class_1799 dropFor(class_2248 block) {
		class_2960 target = mappings.get(class_7923.field_41175.method_10221(block));
		class_2248 targetBlock = target == null ? null : class_7923.field_41175.method_10223(target);
		return targetBlock == null ? class_1799.field_8037 : new class_1799(targetBlock.method_8389());
	}
	public boolean enabled() { return enabled; }
	public long seed() { return seed; }
	public int size() { return mappings.size(); }
	public Map<class_2960, class_2960> mappings() { return Collections.unmodifiableMap(mappings); }

	// ===== Public Mutator Methods =====
	public void setEnabled(boolean value) { enabled = value; method_80(); }
	public static void setLastBreak(class_2338 pos, boolean isCreative) {
		BreakContext.set(pos, isCreative);
	}
	public static boolean wasCreativeBreak(class_2338 pos) {
		return pos.equals(BreakContext.getLastPos()) && BreakContext.getLastWasCreative();
	}
	public static void clearBreak() {
		BreakContext.clear();
	}
	public void regenerate(long newSeed) {
		seed = newSeed;
		List<class_2960> ids = eligibleIds();
		List<class_2960> shuffled = new ArrayList<>(ids);
		Collections.shuffle(shuffled, new java.util.Random(seed));
		mappings.clear();
		for (int i = 0; i < ids.size(); i++) mappings.put(ids.get(i), shuffled.get(i));
		method_80();

	}

	// ===== Private Helper Methods =====
	private void ensureCurrentPool() {
		Set<class_2960> eligible = new HashSet<>(eligibleIds());
		if (!eligible.equals(mappings.keySet()) || !eligible.equals(new HashSet<>(mappings.values()))) regenerate(seed);
	}
	private List<class_2960> eligibleIds() {
		List<class_2960> result = new ArrayList<>();
		for (class_2248 block : class_7923.field_41175) {
			class_2960 id = class_7923.field_41175.method_10221(block);
			if (block.method_8389() == class_1802.field_8162 || OPERATOR_BLOCKS.contains(id.toString())) continue;
			result.add(id);
		}
		Collections.sort(result);
		return result;
	}
}
