package com.proman280.randomblockdrops.command;

import com.mojang.brigadier.CommandDispatcher;
import com.proman280.randomblockdrops.RandomBlockDrops;
import com.proman280.randomblockdrops.RandomDropState;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_5819;

/** Native commands are the administration fallback for clients without the optional UI. */
public final class RandomBlockDropsCommands {
	// ===== Constructor =====
	private RandomBlockDropsCommands() { }

	// ===== Registration =====
	public static void register(CommandDispatcher<class_2168> dispatcher) {
		var root = class_2170.method_9247("randomblockdrops")
			.then(class_2170.method_9247("randomize").requires(source -> source.method_9259(2)).executes(ctx -> randomize(ctx.getSource())))
			.then(class_2170.method_9247("toggle").requires(source -> source.method_9259(2)).executes(ctx -> toggle(ctx.getSource())));
		dispatcher.register(root);
		dispatcher.register(class_2170.method_9247("rbd").redirect(root.build()));
	}

	// ===== Command Handlers =====
	private static int randomize(class_2168 source) {
		RandomDropState state = RandomBlockDrops.state(source.method_9211());
		state.regenerate(class_5819.method_43047().method_43055());
		source.method_9226(() -> class_2561.method_43470("Random Block Drops loot pool randomized."), true);
		return 1;
	}
	private static int toggle(class_2168 source) {
		RandomDropState state = RandomBlockDrops.state(source.method_9211());
		boolean enabled = !state.enabled();
		state.setEnabled(enabled);
		source.method_9226(() -> class_2561.method_43470("Random Block Drops: " + (enabled ? "enabled" : "disabled") + "."), true);
		return 1;
	}
}
